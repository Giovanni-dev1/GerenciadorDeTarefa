from flask import Flask, render_template, request, redirect

# criando o app
app = Flask(__name__)

# lista simples pra guardar tarefas
minhas_tarefas = []


# página principal
@app.route("/")
def pagina_inicial():
    return render_template("index.html", lista=minhas_tarefas)


# adicionar tarefa
@app.route("/add", methods=["POST"])
def adicionar():

    texto = request.form.get("tarefa")

    # se não estiver vazio
    if texto != "" and texto != None:
        tarefa_nova = {
            "texto": texto,
            "feito": False
        }

        minhas_tarefas.append(tarefa_nova)

    return redirect("/")


# marcar como feita
@app.route("/fazer/<int:numero>")
def marcar(numero):

    if numero < len(minhas_tarefas):
        minhas_tarefas[numero]["feito"] = True

    return redirect("/")


# apagar tarefa
@app.route("/apagar/<int:numero>")
def apagar(numero):

    if numero < len(minhas_tarefas):
        minhas_tarefas.pop(numero)

    return redirect("/")


# rodar servidor
if __name__ == "__main__":
    app.run(debug=True)